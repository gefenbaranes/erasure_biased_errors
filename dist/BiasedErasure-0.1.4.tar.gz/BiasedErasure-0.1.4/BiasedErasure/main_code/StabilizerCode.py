
class StabilizerCode:
    def __init__(self) -> None:
        self.stabilizers = self.get_stabilizers()

    def get_stabilizers(self):
        pass
    
    def get_data_ancilla_indices(self):
        pass
    
    def get_circuit(self):
        pass
