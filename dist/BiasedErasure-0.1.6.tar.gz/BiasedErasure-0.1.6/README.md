# BiasedErasure


To install the package so that you can call it from the command line, run either "pip install -e ." (developer instillation) or "pip install ." (regular) from the erasure_biased_errors folder. The former option will reflect local changes that you make to the packages when you run it from the command line. The latter will always call the current version of the code without any local changes.

Important! To use this package, you must you the "loss_decoder" branch in qec package.